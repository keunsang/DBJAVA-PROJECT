package com.zip.dbjava.member.bean;

public class Member {

}
