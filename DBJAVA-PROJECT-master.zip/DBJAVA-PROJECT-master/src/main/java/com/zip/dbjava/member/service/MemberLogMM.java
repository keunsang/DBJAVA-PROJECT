package com.zip.dbjava.member.service;

public class MemberLogMM {

}
