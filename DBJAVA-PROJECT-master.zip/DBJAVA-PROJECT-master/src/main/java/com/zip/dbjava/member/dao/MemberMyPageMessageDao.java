package com.zip.dbjava.member.dao;

import java.util.List;

import com.zip.dbjava.member.bean.Message;

public interface MemberMyPageMessageDao {

	List<Message> mMsgNoticDetail(String me_r_id);
	
	
	
	
	

}
