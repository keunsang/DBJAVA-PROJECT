package com.zip.dbjava.property.dao;

import org.springframework.stereotype.Repository;

import com.zip.dbjava.property.bean.Property;

@Repository
public class PropertyDao {

	public boolean propertyInsert(Property p) {
		return false;
	}

}
