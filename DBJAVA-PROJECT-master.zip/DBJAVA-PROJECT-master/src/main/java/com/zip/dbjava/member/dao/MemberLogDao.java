package com.zip.dbjava.member.dao;

public class MemberLogDao {

}
