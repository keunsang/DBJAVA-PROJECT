package com.zip.dbjava.main.admin.dao;

public interface AdMainDao {

	void adLogin();
	
	
	
	
	
	
}
